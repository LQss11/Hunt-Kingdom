# Drapo-Dashboard-JavaFX
A JavaFX example based on Drapo's dashboard an inspiration ui.
Clone and do your thing.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

![alt text](https://github.com/k33ptoo/Drapo-Dashboard-JavaFX/blob/master/images/img1.png)

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Check out - https://dribbble.com/shots/3750197-Drapo-Pro-s-dashboard?utm_source=Pinterest_Shot&amp;utm_campaign=drapo&amp;utm_content=Drapo%20Pro%27s%20dashboard&amp;utm_medium=Social_Share


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Catch me outside.
* https://www.facebook.com/keeptoo.ui.ux/
* https://www.youtube.com/KeepToo
* https://t.me/byte2bits
