/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import Entite.Evenement;
import Service.ServiceEvenement;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Marwen
 */
public class AfficherEController implements Initializable {

   public void goBack(ActionEvent event) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("DashBoardAdmin.fxml"));
        Scene scene = new Scene(log, 813.0, 596.0);
        
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(scene);
        window.show();
    }  
   
   @FXML TableView <Evenement> eventTable;
    @FXML TableColumn<Evenement , Integer> id;
    @FXML TableColumn<Evenement , String > user;
    @FXML TableColumn<Evenement , String> date;
    @FXML TableColumn<Evenement , String> nbp;
    @FXML TableColumn<Evenement , Integer> note;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
      
        try {

            id.setCellValueFactory(new PropertyValueFactory<>("id-evenement"));
            user.setCellValueFactory(new PropertyValueFactory<>("nom-utilisateur"));
            date.setCellValueFactory(new PropertyValueFactory<>("date"));
            nbp.setCellValueFactory(new PropertyValueFactory<>("nb-place"));
            note.setCellValueFactory(new PropertyValueFactory<>("note"));
            

        }catch (NullPointerException e){
            System.out.println("problem de connection = "+e.getMessage());
        }

        finally{
            try {
                eventTable.setItems(load());
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        }
   
}  
   
    public ObservableList<Evenement> load() throws SQLException {
          ServiceEvenement ser = new ServiceEvenement();
        ResultSet rs = ser.getEvenement();
        ObservableList e = FXCollections.observableArrayList();
        while(rs.next()) {
            e.add(new Evenement(
                  rs.getInt(1),
                   rs.getString(2),
                    rs.getString(3),
                    rs.getInt(4),
                    rs.getInt(5)
            ));
        }
        eventTable.setItems(e);
        return e;
    }
    


    
    
    
    
   
    
   
   
}
