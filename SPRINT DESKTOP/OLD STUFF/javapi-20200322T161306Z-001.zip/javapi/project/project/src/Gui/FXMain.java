/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import Entite.User;
import java.io.IOException;
import static java.lang.Math.log;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author wiemhjiri
 */
public class FXMain extends Application {
    
   
    @Override
    public void start(Stage primaryStage) throws IOException {
        
      
        Parent root=FXMLLoader.load(getClass().getResource("AfficherE.fxml"));
        //Scene scene = new Scene(root, 813.0, 596.0);
        Scene scene = new Scene(root, 1004.0,762.0);
        primaryStage.setTitle("Dash Board Admin");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    
    
}
