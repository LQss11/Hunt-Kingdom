package Gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;


public class DashBoardAdminController {

    @FXML
    private Button contestantForm;
    @FXML
    private Button gback;
    @FXML
    private Button volunteerForm;
    @FXML
    private Button C_v;
    @FXML
    private Button viewEvent;
    @FXML
    private Button C_v1;

    @FXML
    public void AjouterE(ActionEvent Evenement) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("AjouterE.fxml"));
        Scene scene = new Scene(log, 1004.0,762.0);
        Stage window = (Stage)((Node)Evenement.getSource()).getScene().getWindow();
        window.setX(0.0);
        window.setY(0.0);
        window.setResizable(false);
        window.setScene(scene);
        window.show();
    }

    public void showEForm(ActionEvent event) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("eventForm.fxml"));
        Scene scene = new Scene(log, 1004.0,762.0);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setX(0.0);
        window.setY(0.0);
        window.setResizable(false);
        window.setScene(scene);
        window.show();
    }

    @FXML
    public void showVForm(ActionEvent event) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("volunteerForm.fxml"));
        Scene scene = new Scene(log, 1004.0,762.0);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setX(0.0);
        window.setY(0.0);
        window.setResizable(false);
        window.setScene(scene);
        window.show();
    }

    public void showCTable(ActionEvent event) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("ContestantTable.fxml"));
        Scene scene = new Scene(log, 1004.0,762.0);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setX(0.0);
        window.setY(0.0);
        window.setResizable(false);
        window.setScene(scene);
        window.show();
    }

    public void showVTable(ActionEvent event) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("volunteerTable.fxml"));
        Scene scene = new Scene(log, 1004.0,762.0);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setX(0.0);
        window.setY(0.0);
        window.setResizable(false);
        window.setScene(scene);
        window.show();
    }

    @FXML
    public void showETable(ActionEvent event) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("eventTable.fxml"));
        Scene scene = new Scene(log, 1004.0,762.0);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setX(0.0);
        window.setY(0.0);
        window.setResizable(false);
        window.setScene(scene);
        window.show();
    }

    @FXML
    public void goBack(ActionEvent event) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene scene = new Scene(log, 719.0, 551.0);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setX(0.0);
        window.setY(0.0);
        window.setResizable(false);
        window.setScene(scene);
        window.show();

    }
}
