package Gui;

import Entite.Evenement;
import Entite.User;
import Service.ServiceEvenement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.xml.transform.Result;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.beans.value.ObservableValue;
import javax.swing.JOptionPane;


public class AjouterEController implements Initializable{


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 

    public AjouterEController() throws Exception {
    }

    public void goBack(ActionEvent event) throws Exception{
        Parent log = FXMLLoader.load(getClass().getResource("DashBoardAdmin.fxml"));
        Scene scene = new Scene(log, 813.0, 596.0);
        
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(scene);
        window.show();
    }


   //
   
 



   
    @FXML
    DatePicker eventDate;

    public String eventDate(){
        LocalDate date =  eventDate.getValue();
        int a =  date.getDayOfMonth();
        int b = date.getYear();
        int c = date.getMonthValue();
       
        return b+"-"+c+"-"+a ;
    }

    @FXML
    TextArea note;
    @FXML
    TextArea note1;
    
 
 

 
  
        
   public void Ajouter() throws Exception {
         
      User u= new User("1","abessi","marwen","marwen.abessi@esprit.tn","0000","Admin"); 
        ServiceEvenement ser = new ServiceEvenement();
     Evenement e = new Evenement(1,u.getUser(), eventDate().toString(), Integer.parseInt(note1.getText()),Integer.parseInt(note1.getText()) );
 
   
       
       
           try {
             ser.ajouter(e);
            } catch (SQLException ex) {
            System.out.println(ex);}
           JOptionPane.showMessageDialog(null, "Ajout effectué");

        

   }

   

}
