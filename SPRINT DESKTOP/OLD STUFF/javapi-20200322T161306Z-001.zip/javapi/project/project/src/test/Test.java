/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import Entite.Evenement;
import Service.ServiceEvenement;
import Utils.DataBase;
import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
* @author marwen
 */
public class Test {
    
    public static void main(String[] args) throws SQLException {
        ServiceEvenement ser = new ServiceEvenement();
        
       // Evenement e = new Evenement("nom user ","",1,1,"");
       
        
      
      /*
        try {
        
            
           ser.ajouter(e);
           // ser.delete(e);
           //ser.update(e);
          // ser.reservation(e);
            /*List<Evenement> list = ser.readAll();
            System.out.println(list);
        } catch (SQLException ex) {
            System.out.println(ex);
        }*/
    }
    
}
