/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

/**
 *
* @author marwen
 */
public class Evenement {
   
    private String nom_utilisateur;
    private String date;
    private int nbr_place;
    private int note;
    private int id;
         private String Id_evenement;

    public String getId_evenement() {
        return Id_evenement;
    }

    public void setId_evenement(String Id_evenement) {
        this.Id_evenement = Id_evenement;
    }
   

    public String getNom_utilisateur() {
        return nom_utilisateur;
    }

    public void setNom_utilisateur(String nom_utilisateur) {
        this.nom_utilisateur = nom_utilisateur;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getNbr_place() {
        return nbr_place;
    }

    public void setNbr_place(int nbr_place) {
        this.nbr_place = nbr_place;
    }

    public int getNote() {
        return note;
    }

    public void setNote(int note) {
        this.note = note;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Evenement(int id, String nom_utilisateur, String date, int nbr_place, int note ) {
       
        this.nom_utilisateur = nom_utilisateur;
        this.date = date;
        this.nbr_place = nbr_place;
        this.note = note;
        this.id = id;
    }

   


    
}
